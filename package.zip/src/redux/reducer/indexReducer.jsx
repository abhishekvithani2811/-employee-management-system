import { combineReducers } from "redux";
import viewDetail_Reducer from "./viewDetail_Reducer";

const indexReducer=combineReducers({
    viewDetail_Reducer,
})

export default indexReducer